import React from 'react';
import { Star, MapPin, Calendar, Award } from 'lucide-react';

const Doctors = () => {
  const doctors = [
    {
      name: 'Dr. Ahmad Wijaya, Sp.JP',
      specialty: 'Spesialis Jantung',
      experience: '15 Tahun',
      rating: 4.9,
      education: 'Universitas Indonesia',
      image: 'https://images.pexels.com/photos/612808/pexels-photo-612808.jpeg?auto=compress&cs=tinysrgb&w=400',
      schedule: 'Senin - Jumat',
      awards: ['Best Cardiologist 2023', 'Excellence in Patient Care']
    },
    {
      name: 'Dr. Siti Nurhaliza, Sp.A',
      specialty: 'Spesialis Anak',
      experience: '12 Tahun',
      rating: 4.8,
      education: 'Universitas Gadjah Mada',
      image: 'https://images.pexels.com/photos/5327647/pexels-photo-5327647.jpeg?auto=compress&cs=tinysrgb&w=400',
      schedule: 'Selasa - Sabtu',
      awards: ['Pediatric Excellence Award', 'Top Doctor 2023']
    },
    {
      name: 'Dr. Budi Santoso, Sp.BS',
      specialty: 'Spesialis Bedah Saraf',
      experience: '18 Tahun',
      rating: 4.9,
      education: 'Universitas Airlangga',
      image: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=400',
      schedule: 'Senin - Kamis',
      awards: ['Neurosurgery Innovation Award', 'Medical Excellence 2023']
    },
    {
      name: 'Dr. Maya Sari, Sp.M',
      specialty: 'Spesialis Mata',
      experience: '10 Tahun',
      rating: 4.7,
      education: 'Universitas Padjadjaran',
      image: 'https://images.pexels.com/photos/5452207/pexels-photo-5452207.jpeg?auto=compress&cs=tinysrgb&w=400',
      schedule: 'Rabu - Minggu',
      awards: ['Ophthalmology Excellence', 'Patient Choice Award']
    },
    {
      name: 'Dr. Rudi Hartono, Sp.OT',
      specialty: 'Spesialis Ortopedi',
      experience: '14 Tahun',
      rating: 4.8,
      education: 'Universitas Brawijaya',
      image: 'https://images.pexels.com/photos/6129967/pexels-photo-6129967.jpeg?auto=compress&cs=tinysrgb&w=400',
      schedule: 'Senin - Jumat',
      awards: ['Orthopedic Surgery Award', 'Sports Medicine Excellence']
    },
    {
      name: 'Dr. Lisa Wijayanti, Sp.OG',
      specialty: 'Spesialis Kandungan',
      experience: '11 Tahun',
      rating: 4.9,
      education: 'Universitas Diponegoro',
      image: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=400',
      schedule: 'Selasa - Sabtu',
      awards: ['Women Health Excellence', 'Maternal Care Award']
    }
  ];

  return (
    <section id="dokter" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-sky-100 text-sky-700 rounded-full text-sm font-medium mb-4">
            Tim Medis
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Dokter Spesialis
            <span className="text-sky-600"> Berpengalaman</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Tim dokter spesialis kami terdiri dari tenaga medis terbaik dengan pengalaman 
            internasional dan dedikasi tinggi untuk kesehatan pasien.
          </p>
        </div>

        {/* Doctors Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {doctors.map((doctor, index) => (
            <div 
              key={index} 
              className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group"
            >
              {/* Doctor Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={doctor.image}
                  alt={doctor.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-whit