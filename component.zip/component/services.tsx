import React from 'react';
import { 
  Stethoscope, 
  Heart, 
  Brain, 
  Baby, 
  Eye, 
  Bone, 
  Activity, 
  Microscope,
  ArrowRight 
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Heart,
      title: 'Kardiologi',
      description: 'Pelayanan jantung dan pembuluh darah dengan teknologi terdepan',
      features: ['EKG', 'Echocardiography', 'Kateterisasi Jantung', 'Bypass Surgery']
    },
    {
      icon: Brain,
      title: 'Neurologi',
      description: 'Diagnosa dan pengobatan gangguan sistem saraf',
      features: ['MRI Brain', 'CT Scan', 'EEG', 'Neurosurgery']
    },
    {
      icon: Baby,
      title: 'Pediatri',
      description: 'Perawatan kesehatan khusus untuk bayi dan anak-anak',
      features: ['NICU', 'Vaksinasi', 'Tumbuh Kembang', 'Pediatric Surgery']
    },
    {
      icon: Eye,
      title: 'Oftalmologi',
      description: 'Pemeriksaan dan pengobatan mata komprehensif',
      features: ['Lasik', 'Katarak', 'Glaukoma', 'Retina']
    },
    {
      icon: Bone,
      title: 'Ortopedi',
      description: 'Pengobatan tulang, sendi, dan sistem muskuloskeletal',
      features: ['Arthroscopy', 'Joint Replacement', 'Spine Surgery', 'Sports Medicine']
    },
    {
      icon: Activity,
      title: 'Gawat Darurat',
      description: 'Pelayanan 24 jam untuk keadaan darurat medis',
      features: ['Trauma Center', 'ICU', 'Ambulance', 'Emergency Surgery']
    },
    {
      icon: Microscope,
      title: 'Laboratorium',
      description: 'Pemeriksaan laboratorium lengkap dan akurat',
      features: ['Hematologi', 'Kimia Klinik', 'Mikrobiologi', 'Patologi']
    },
    {
      icon: Stethoscope,
      title: 'Penyakit Dalam',
      description: 'Diagnosis dan pengobatan penyakit internal',
      features: ['Diabetes', 'Hipertensi', 'Gastroenterologi', 'Endokrinologi']
    }
  ];

  return (
    <section id="layanan" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-teal-100 text-teal-700 rounded-full text-sm font-medium mb-4">
            Layanan Medis
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Layanan Kesehatan
            <span className="text-teal-600"> Terlengkap</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Kami menyediakan berbagai layanan medis spesialis dengan standar internasional 
            untuk memenuhi kebutuhan kesehatan Anda dan keluarga.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-gray-50 p-6 rounded-xl hover:bg-white hover:shadow-lg transition-all duration-300 border hover:border-teal-200 group"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-teal-500 to-sky-500 rounded-xl flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform duration-300">
                <service.icon size={28} />
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-600 mb-4 text-sm leading-relaxed">{service.description}</p>
              
              <div className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center text-sm text-gray-500">
                    <div className="w-1.5 h-1.5 bg-teal-500 rounded-full mr-2"></div>
                    {feature}
                  </div>
                ))}
              </div>

              <button className="mt-4 text-teal-600 font-medium text-sm flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span>Pelajari Lebih Lanjut</span>
                <ArrowRight size={16} />
              </button>
            </div>
          ))}
        </div>

        {/* Emergency Call-to-Action */}
        <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl p-8 text-center text-white">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">Butuh Bantuan Darurat?</h3>
            <p className="text-red-100 mb-6 text-lg">
              Tim gawat darurat kami siap melayani 24 jam setiap hari. 
              Jangan ragu untuk menghubungi kami dalam situasi emergency.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="tel:021-555-0123" 
                className="bg-white text-red-600 px-8 py-3 rounded-xl font-semibold hover:bg-red-50 transition-colors inline-flex items-center justify-center space-x-2"
              >
                <span>Hubungi Darurat: (021) 555-0123</span>
              </a>
              <button className="border-2 border-white text-white px-8 py-3 rounded-xl font-semibold hover:bg-white hover:text-red-600 transition-colors">
                Lokasi Rumah Sakit
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;