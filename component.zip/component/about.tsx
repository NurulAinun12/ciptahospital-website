import React from 'react';
import { Award, Users, Heart, Shield, Clock, Star } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: Award,
      title: 'Akreditasi Nasional',
      description: 'Terakreditasi A dari Komisi Akreditasi Rumah Sakit'
    },
    {
      icon: Users,
      title: 'Tim Medis Berpengalaman',
      description: 'Dokter spesialis dan tenaga medis profesional'
    },
    {
      icon: Heart,
      title: 'Pelayanan Holistik',
      description: 'Perawatan menyeluruh untuk kesehatan optimal'
    },
    {
      icon: Shield,
      title: 'Standar Keamanan Tinggi',
      description: 'Protokol keamanan dan kebersihan internasional'
    }
  ];

  const achievements = [
    { icon: Star, number: '4.8/5', label: 'Rating Kepuasan Pasien' },
    { icon: Users, number: '200+', label: 'Tenaga Medis Profesional' },
    { icon: Clock, number: '24/7', label: 'Layanan Gawat Darurat' },
    { icon: Award, number: '15+', label: 'Penghargaan Nasional' }
  ];

  return (
    <section id="tentang" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-sky-100 text-sky-700 rounded-full text-sm font-medium mb-4">
            Tentang Kami
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Mengabdi untuk Kesehatan
            <span className="text-sky-600"> Indonesia</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Sejak 1998, RS Sehat Sejahtera telah menjadi pilihan utama keluarga Indonesia 
            untuk mendapatkan pelayanan kesehatan berkualitas tinggi dengan sentuhan kemanusiaan.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">
                Komitmen Kami untuk Keunggulan
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Kami memahami bahwa kesehatan adalah aset paling berharga. Oleh karena itu, 
                kami berkomitmen untuk memberikan pelayanan terbaik melalui inovasi teknologi medis, 
                pengembangan SDM berkelanjutan, dan pendekatan pelayanan yang mengutamakan kenyamanan pasien.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Dengan dukungan peralatan medis canggih dan tim medis berpengalaman, 
                kami siap melayani berbagai kebutuhan kesehatan mulai dari pemeriksaan rutin 
                hingga tindakan medis kompleks.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow duration-300">
                  <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center text-white mb-4">
                    <feature.icon size={24} />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">{feature.title}</h4>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="relative w-full h-96 lg:h-[500px] rounded-2xl overflow-hidden shadow-xl">
              <img
                src="https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Medical Team"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
            </div>
            
            {/* Floating Achievement Card */}
            <div className="absolute -top-6 -right-6 bg-white p-6 rounded-xl shadow-xl border">
              <div className="text-center">
                <div className="text-3xl font-bold text-sky-600 mb-1">25+</div>
                <div className="text-sm text-gray-600">Tahun Melayani</div>
              </div>
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="grid md:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl text-white mb-4">
                  <achievement.icon size={28} />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{achievement.number}</div>
                <div className="text-gray-600">{achievement.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;