import React from 'react';
import { ArrowRight, Shield, Heart, Users } from 'lucide-react';

const Hero = () => {
  const stats = [
    { icon: Users, number: '50,000+', label: 'Pasien Dilayani' },
    { icon: Shield, number: '25+', label: 'Tahun Pengalaman' },
    { icon: Heart, number: '24/7', label: 'Layanan Darurat' },
  ];

  return (
    <section id="beranda" className="relative min-h-screen flex items-center pt-20">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-sky-50 via-white to-teal-50"></div>
      
      {/* Decorative Elements */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-sky-200/30 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-teal-200/20 rounded-full blur-3xl"></div>

      <div className="relative max-w-7xl mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-block px-4 py-2 bg-sky-100 text-sky-700 rounded-full text-sm font-medium">
                ✨ Rumah Sakit Terpercaya di Jakarta
              </div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Kesehatan Anda,
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-600 to-teal-600">
                  {' '}Prioritas Kami
                </span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                RS Sehat Sejahtera memberikan pelayanan kesehatan terbaik dengan teknologi modern, 
                tenaga medis profesional, dan fasilitas lengkap untuk keluarga Indonesia.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-gradient-to-r from-sky-600 to-teal-600 text-white px-8 py-4 rounded-xl font-semibold flex items-center justify-center space-x-2 hover:shadow-lg transition-all duration-300 group">
                <span>Buat Janji Temu</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-colors duration-300">
                Hubungi Kami
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl text-white mb-3">
                    <stat.icon size={24} />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{stat.number}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Image/Visual */}
          <div className="relative">
            <div className="relative w-full h-96 lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/236380/pexels-photo-236380.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Modern Hospital Interior"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
            
            {/* Floating Card */}
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-xl border">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <Shield className="text-green-600" size={24} />
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Akreditasi A</div>
                  <div className="text-sm text-gray-600">Standar Internasional</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;